"use client";

import Link from "next/link";
import { useState } from "react";
import { ApplicationRefused, formatDate, SessionEnded, submitApplication, type JobPosting } from "@/lib/api";
import { checkApplication, type Desk } from "@/lib/apply";
import { APPLICATION_LIMIT } from "@/lib/sampleDesk";
import type { Session } from "@/lib/session";
import { useEndSession } from "@/lib/useEndSession";
import PageTitle from "./PageTitle";
import ResumeOnFile from "./ResumeOnFile";
import SlotMeter from "./SlotMeter";

export default function ApplyForm({ posting, session, desk }: { posting: JobPosting; session: Session; desk: Desk }) {
  const applicant = session.user;
  const endSession = useEndSession();
  const [acknowledged, setAcknowledged] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [activeCount, setActiveCount] = useState<number | null>(null); // set once submitted

  if (activeCount !== null) {
    return <Submitted posting={posting} activeCount={activeCount} />;
  }

  const check = checkApplication(posting, desk);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const submitted = await submitApplication(session.token, posting.jobPostId);
      setActiveCount(submitted.activeApplicationCount);
    } catch (err) {
      if (err instanceof SessionEnded) {
        endSession();
      }
      setError(
        err instanceof ApplicationRefused && err.message
          ? err.message
          : err instanceof SessionEnded
            ? "Your session has ended. Log in again, then submit the application."
            : "Unable to submit the application. Please try again.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5 lg:flex-row lg:items-start lg:gap-6">
      <article className="card min-w-0 flex-1 border border-base-300 bg-base-100">
        <div className="card-body gap-5">
          <Link href={`/jobs/${posting.jobPostId}`} className="link link-primary font-semibold">
            Back to the posting
          </Link>

          <div>
            <PageTitle
              eyebrow="You are applying for"
              subtitle={`${posting.organization.name} · ${posting.location} · ${posting.employmentType}`}
            >
              {posting.title}
            </PageTitle>
            <p className="text-sm text-muted">Apply by {formatDate(posting.applicationDeadline)}</p>
          </div>

          {check.kind !== "ok" && <Blocked check={check} />}
          {error && (
            <div role="alert" className="alert alert-error">
              <span>{error}</span>
            </div>
          )}

          <section>
            <h2 className="text-lg font-semibold">Your details</h2>
            <dl className="mt-2 grid gap-4 sm:grid-cols-3">
              <div>
                <dt className="text-sm text-muted">Name</dt>
                <dd className="font-medium">
                  {applicant.firstName} {applicant.lastName}
                </dd>
              </div>
              <div>
                <dt className="text-sm text-muted">Email</dt>
                <dd className="font-medium">{applicant.email}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">Phone</dt>
                <dd className="font-medium">{applicant.phone ?? "Not given"}</dd>
              </div>
            </dl>
            <p className="mt-2 text-sm text-muted">
              These go to {posting.organization.name} with your application.{" "}
              <Link href="/profile" className="link link-primary">
                Edit profile
              </Link>
            </p>
          </section>

          {check.kind === "ok" && (
            <section className="flex flex-col gap-4 border-t border-base-300 pt-5">
              <label className="flex cursor-pointer items-start gap-3">
                <input
                  type="checkbox"
                  className="checkbox checkbox-primary mt-0.5"
                  checked={acknowledged}
                  onChange={(event) => setAcknowledged(event.target.checked)}
                />
                <span>
                  I understand that a submitted application cannot be edited. To change it, I would
                  withdraw it and apply again if the posting is still open.
                </span>
              </label>
              <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                <Link href={`/jobs/${posting.jobPostId}`} className="btn">
                  Cancel
                </Link>
                <button type="submit" className="btn btn-primary" disabled={!acknowledged || submitting}>
                  Submit application
                </button>
              </div>
            </section>
          )}
        </div>
      </article>

      <aside className="flex flex-col gap-4 lg:w-80 lg:shrink-0">
        <ResumeOnFile resume={desk.resume}>
          <p className="pt-2 text-sm text-muted">
            A copy as it is now goes with this application; later changes do not affect it.
          </p>
        </ResumeOnFile>

        <SlotMeter used={desk.applications.length} total={APPLICATION_LIMIT} />
      </aside>
    </form>
  );
}

function Blocked({ check }: { check: Exclude<ReturnType<typeof checkApplication>, { kind: "ok" }> }) {
  switch (check.kind) {
    case "closed":
      return (
        <div role="status" className="alert alert-warning">
          <span>
            This posting no longer accepts applications.{" "}
            <Link href="/jobs" className="link">
              See other open jobs
            </Link>
          </span>
        </div>
      );
    case "no-resume":
      return (
        <div role="status" className="alert alert-warning">
          <span>
            A resume is required to apply.{" "}
            <Link href="/profile" className="link">
              Upload one in Profile &amp; resume
            </Link>
            , then come back to this posting.
          </span>
        </div>
      );
    case "already-applied":
      return (
        <div role="status" className="alert alert-warning">
          <span>
            You already applied to this posting;{" "}
            {check.application ? (
              <>
                the application is at the <strong>{check.application.applicationStatus}</strong> stage.
              </>
            ) : (
              "that application has ended."
            )}{" "}
            A posting can be applied to once.{" "}
            <Link href="/applications" className="link">
              Track its status
            </Link>
          </span>
        </div>
      );
    case "limit":
      return (
        <div role="status" className="alert alert-warning flex-col items-start">
          <p>
            You have {APPLICATION_LIMIT} active applications, the most allowed at once. A slot
            frees up when you withdraw one or it reaches Hired, Rejected or Offer Declined.
          </p>
          <ul className="list-inside list-disc">
            {check.active.map((application) => (
              <li key={application.applicationId}>
                {application.title}, {application.organizationName} ·{" "}
                {application.applicationStatus}
              </li>
            ))}
          </ul>
          <Link href="/applications" className="link">
            Review your applications
          </Link>
        </div>
      );
  }
}

function Submitted({ posting, activeCount }: { posting: JobPosting; activeCount: number }) {
  return (
    <article className="card border border-base-300 bg-base-100">
      <div className="card-body gap-5">
        <div className="flex size-12 items-center justify-center rounded-full bg-secondary text-secondary-content">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            className="size-6"
          >
            <path d="M5 12.5l4.5 4.5L19 7.5" />
          </svg>
        </div>
        <PageTitle
          subtitle={`${posting.title} at ${posting.organization.name}. You now have ${activeCount} of ${APPLICATION_LIMIT} active applications.`}
        >
          Application submitted
        </PageTitle>
        <p>
          A copy of your resume went with it. The recruiter sees your application at the Applied
          stage; every change of stage will appear in Track status.
        </p>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Link href="/applications" className="btn btn-primary">
            Track application status
          </Link>
          <Link href="/jobs" className="btn">
            Back to open jobs
          </Link>
        </div>
      </div>
    </article>
  );
}
